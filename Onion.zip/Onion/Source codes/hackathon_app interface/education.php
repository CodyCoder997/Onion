<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
        <link href="stylesheet/indexcss.css" rel="stylesheet" type="text/css"/>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        include "navbar.php"
        ?>
        <section class="vh-100 gradient-custom">
            
            <div class="container py-5 h-100" >
                <div class="row d-flex justify-content-center align-items-center h-100" >

                        <div class="card bg-dark text-white" style="border-radius: 1rem;">
                            <div class="card-body p-5 text-center">

                                <div class="mb-md-10 mt-md-10 pb-5">
                                    
                 
                                    
                                    <h3>phishing</h3>
                                    <h5>what is phishing?</h5>
                                    
                                    <p>
                                        Phishing is a type of social engineering attack often used to steal user data,
                                        including login credentials and credit card numbers. It occurs when an attacker,
                                        masquerading as a trusted entity, dupes a victim into opening an email, 
                                        instant message, or text message. The recipient is then tricked into clicking a malicious link,
                                        which can lead to the installation of malware, the freezing of the system as part of a ransomware attack
                                        or the revealing of sensitive information.
                                        
                                    </p>
                                    
                                    <h5>examples of phishing Emails and links</h5>
                                    <img src="images/phishing.jpg" alt="Card image" style="width: 700px; height: 500px">
                                    <br><br>
                                    <img src="images/phishing1.jpg" alt="Card image">
                                    <br><br>                                       
                                    <h5>how do i protect myself against phishing scams</h5>
                                    <p>For users, vigilance is key. A spoofed message often contains subtle mistakes that expose its true identity.
                                        These can include spelling mistakes or changes to domain names, as seen in the earlier URL example.
                                        Users should also stop and think about why they’re even receiving such an email.
                                    </p>
                                    <p>Two-factor authentication (2FA) is the most effective method for countering phishing attacks,
                                        as it adds an extra verification layer when logging in to sensitive applications.
                                        2FA relies on users having two things: something they know, such as a password and user name, 
                                        and something they have, such as their smartphones. 
                                    </p>
                                    <button><a href="quiz.php"> Quiz Me </a> </button> 
                                </div>

                                <div>

                                </div>

                            </div>
                        </div>
                    </div>
                </div>

        </section>
    </body>
</html>
