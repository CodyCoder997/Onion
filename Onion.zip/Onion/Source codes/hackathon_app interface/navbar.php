
<link href="stylesheet/navbar.css" rel="stylesheet" type="text/css"/>
<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="home.php">ONION</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="collapsibleNavbar">
            <ul class="navbar-nav">

                <li class="nav-item dropdown">
                    <a class="nav-link" href="passwordbank.php" role="button">Password Bank</a>
                    <ul class="dropdown-menu">
                    </ul>
                </li>
                
                <li class="nav-item dropdown">
                    <a class="nav-link" href="education.php" role="button">Education</a>
                    <ul class="dropdown-menu">
                    </ul>
                </li>

            </ul>
            <br><br/>
        </div>

        
    </div>
</nav>