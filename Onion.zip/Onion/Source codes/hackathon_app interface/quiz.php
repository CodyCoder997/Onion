<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
        <link href="stylesheet/indexcss.css" rel="stylesheet" type="text/css"/>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        include "navbar.php"
        ?>
        <section class="vh-100 gradient-custom">

            <div class="container py-5 h-100" >
                <div class="row d-flex justify-content-center align-items-center h-100" >

                    <div class="card bg-dark text-white" style="border-radius: 1rem;">
                        <div class="card-body p-5 text-center">

                            <div class="mb-md-10 mt-md-4 pb-5">

                                <h1>Quiz Time</h1>

                                <h3>you'll be putting your new knowledge of phishing to the test</h3>
                                <br><br>

                                <h4>what type of attack is phising categorised under</h4>
                                <h5>social engineering - denial of service - man in the middle - trojan</h5>

                                <br><br>

                                <h4>select the best way to protect yourself against phising</h4>
                                <h5>enabling 2FA - using a weak password - doing nothing - clicking suspicious links</h5>

                                <br><br>

                                <h4>which action downloads the backdoor</h4>
                                <h5>clicking the suspicious link - doing nothing - replying to the email - deleting the email</h5>
                                
                                <br><br>
                                
                                
                                <button href="#"> submit answers </button>
                            </div>

                            <div>

                            </div>

                        </div>
                    </div>
                </div>
            </div>

        </section>
    </body>
</html>
