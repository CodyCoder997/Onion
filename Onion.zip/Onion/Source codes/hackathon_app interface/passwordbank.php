<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
        <link href="stylesheet/indexcss.css" rel="stylesheet" type="text/css"/>
        <meta charset="UTF-8">
        <title></title>
        <style>
            .topright {
                position: absolute;
                top: 8px;
                right: 16px;
                font-size: 18px;
            }
            table {
                font-family: arial, sans-serif;
                border-collapse: collapse;
                width: 90%;
                
            }

            td, th {
                border: 1px solid #dddddd;
                text-align: left;
                padding: 8px;
            }


        </style>
    </head>
    <body>
        <?php
        include "navbar.php"
        ?>
        <section class="vh-100 gradient-custom">
            
            <div class="container py-5 h-100" >
                <div class="row d-flex justify-content-center align-items-center h-100" >

                        <div class="card bg-dark text-white" style="border-radius: 1rem;">
                            <div class="card-body p-5 text-center">

                                <div class="mb-md-10 mt-md-4 pb-5">
                                    
                                    <h1>Password Manager</h1>

                                    <div class="topright">
                                        <form action="#.php"></form>
                                        <input type="text" placeholder="Search.." name="search">
                                        <button type="submit">Submit</button>
                                        </form>
                                    </div>

                                    <table>
                                        <tr>
                                            <th>website</th>
                                            <th>username</th>
                                            <th>password</th>
                                            <th>date</th>
                                        </tr>
                                        <tr>
                                            <td>www.shopee.com</td>
                                            <td>ian123</td>
                                            <td>oJu#Bf98</td>
                                            <td>9/07/22</td>
                                        </tr>
                                        <tr>
                                            <td>google.com</td>
                                            <td>annehian</td>
                                            <td>sT34$nfR</td>
                                            <td>2/01/22</td>
                                        </tr>
                                        <tr>
                                            <td>youtube.com</td>
                                            <td>Quandale Dingle</td>
                                            <td>js#LJ$of</td>
                                            <td>5/01/22</td>
                                        </tr>

                                    </table>




                                </div>

                                <div>

                                </div>

                            </div>
                        </div>
                    </div>
                </div>

        </section>
    </body>
</html>
